<?php


if (!defined('ft_check')) {die('System intrusion ');}
require_once('classes/class.shipment.php');

class esm_email extends Shipment{

}


?>