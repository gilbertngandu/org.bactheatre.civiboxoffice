<?php
//Load JSON handler
define('ft_check','pos');
require_once('../includes/classes/class.router.php');
router::draw('', 'pos/ajax');

?>