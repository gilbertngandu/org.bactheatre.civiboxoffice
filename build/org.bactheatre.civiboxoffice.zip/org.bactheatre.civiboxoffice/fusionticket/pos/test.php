<?php
define('ft_check','pos');
$fond = 'test';
require_once('../includes/controller/pos_template.php');

?>